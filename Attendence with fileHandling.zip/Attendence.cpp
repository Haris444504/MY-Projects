#include <iostream>
#include <fstream>
#include <string>
#include <vector>
using namespace std;

// Base class
class Person {
protected:
    string name;
    int id;
public:
    Person() : name("Unknown"), id(0) {}
    Person(string n, int i) : name(n), id(i) {}
    void getPersonalInfo() {
        cout << "Enter Name: ";
        cin.ignore();
        getline(cin, name);
        cout << "Enter ID: ";
        cin >> id;
    }
    void displayPersonalInfo() {
        cout << "Name: " << name << "\nID: " << id << endl;
    }
    virtual void writeToFile(ofstream &file) {
        file << "Name: " << name << "\nID: " << id << endl;
    
    }
    virtual void readFromFile(ifstream &infile) {
        string line; // Read the line with "Name: "
        getline(infile, name);
        getline(infile, line); // Read the line with "Name: "
        infile >> id;
    }

    
    virtual ~Person() {}
};

// Independent class
class TimeRecord {
protected:
    string inTime;
    string outTime;
public:
    TimeRecord() : inTime("00:00"), outTime("00:00") {}
    void setInTime(string time) { inTime = time; }
    void setOutTime(string time) { outTime = time; }
    string getInTime() const { return inTime; }
    string getOutTime() const { return outTime; }
    virtual void writeToFile(ofstream &file) {
        file << "In Time: " << inTime << "\nOut Time: " << outTime << endl;
    }
    virtual void readFromFile(ifstream &infile) {
        infile >> inTime;
        infile >> outTime;
    }
    virtual ~TimeRecord() {

    }
};

// Attendance class - inherits from TimeRecord
class Attendance : public TimeRecord {
protected:
    int lateInMinutes;
    int earlyGoMinutes;
    int shortHours;
    int excessHours;

   int convertToMinutes(string time) {
    if (time.size() != 5 || time[2] != ':') {
        cerr << "Invalid time format. Expected HH:MM.\n";
        return 0;  
    }
    int hours = stoi(time.substr(0, 2));
    int minutes = stoi(time.substr(3, 2));
    return hours * 60 + minutes;
}
public:
    Attendance() : lateInMinutes(0), earlyGoMinutes(0), shortHours(0), excessHours(0) {}

    void calculateLateIn() {
        int inMins = convertToMinutes(inTime);
        int standardIn = 9 * 60;
        lateInMinutes = (inMins > standardIn) ? (inMins - standardIn) : 0;
    }

    void calculateEarlyGo() {
        int outMins = convertToMinutes(outTime);
        int standardOut = 17 * 60;
        earlyGoMinutes = (outMins < standardOut) ? (standardOut - outMins) : 0;
    }

    void calculateShortAndExcessHours() {
        int totalMinutes = convertToMinutes(outTime) - convertToMinutes(inTime);
        int requiredMinutes = 8 * 60;
        if (totalMinutes < requiredMinutes)
            shortHours = requiredMinutes - totalMinutes;
        else
            excessHours = totalMinutes - requiredMinutes;
    }

    void displayAttendanceReport() {
        cout << "In Time: " << inTime << "\nOut Time: " << outTime << endl;
        cout << "Late In: " << lateInMinutes << " mins\nEarly Go: " << earlyGoMinutes << " mins" << endl;
        cout << "Short Hours: " << shortHours << " mins\nExcess Hours: " << excessHours << " mins\n";
    }
    void writeToFile(ofstream &file) {
        file << "In Time: " << inTime << "\nOut Time: " << outTime << endl;
        file << "Late In: " << lateInMinutes << " mins\nEarly Go: " << earlyGoMinutes << " mins" << endl;
        file << "Short Hours: " << shortHours << " mins\nExcess Hours: " << excessHours << " mins\n";
    }
    void readFromFile(ifstream &infile) {
        infile >> inTime;
        infile >> outTime;
        infile >> lateInMinutes;
        infile >> earlyGoMinutes;
        infile >> shortHours;
        infile >> excessHours;
    }
};

// Teacher class - multiple inheritance
class Teacher : public Person, public Attendance {
private:
    string subject;
    string department;
public:
    Teacher() : Person(), Attendance(), subject("Unknown"), department("Unknown") {}

    Teacher(string n, int i, string sub, string dept)
        : Person(n, i), subject(sub), department(dept) {}

    Teacher(const Teacher &t) : Person(t.name, t.id), Attendance(t),
        subject(t.subject), department(t.department) {}

    void getTeacherDetails() {
        getPersonalInfo();
        cin.ignore();
        cout << "Enter Subject: ";
        getline(cin, subject);
        cout << "Enter Department: ";
        getline(cin, department);
        cout << "Enter In Time (HH:MM): ";
        getline(cin, inTime);
        cout << "Enter Out Time (HH:MM): ";
        getline(cin, outTime);

        setInTime(inTime);
        setOutTime(outTime);

        calculateLateIn();
        calculateEarlyGo();
        calculateShortAndExcessHours();
    }

    void displayTeacherInfo() {
        displayPersonalInfo();
        cout << "Subject: " << subject << "\nDepartment: " << department << endl;
        displayAttendanceReport();
    }
    void writeToFile(ofstream &file) {
        Person::writeToFile(file);
        Attendance::writeToFile(file);
        file << "Subject: " << subject << "\nDepartment: " << department << endl;
    }
    void readFromFile(ifstream &infile) {
        Person::readFromFile(infile);
        Attendance::readFromFile(infile);
        infile.ignore();
        getline(infile, subject);
        getline(infile, department);
    }
};

class Admin : public Person {
private:
    string role;
public:
    Admin() : Person(), role("None") {}
    Admin(string n, int i, string r) : Person(n, i), role(r) {}

    void manageTeachers() {
        cout << "Admin managing teacher records\n";
    }

    void viewReports() {
        cout << "Admin viewing reports.\n";
    }
    
};

class Department : protected Teacher {
private:
    string departmentName;
    int numberOfTeachers;
public:
    Department() : departmentName("N/A"), numberOfTeachers(0) {}
    void setDepartmentInfo(string name, int count) {
        departmentName = name;
        numberOfTeachers = count;
    }

    void displayDepartmentInfo() {
        cout << "Department: " << departmentName << "\nNumber of Teachers: " << numberOfTeachers << endl;
    }
};


class ReportGenerator {
private:
    vector<Teacher> teachers; 
    string reportDate;
    const string filename = "teacher_data.txt"; 
public:
    ReportGenerator() : reportDate("01-01-2025") {}

    void inputTeachers() {
        int numTeachers;
        cout << "How many teachers do you want to enter? ";
        cin >> numTeachers;
    

        teachers.clear(); 
        for (int i = 0; i < numTeachers; ++i) {
            Teacher t;
            cout << "\nInput for Teacher " << (i + 1) << ":\n";
            t.getTeacherDetails(); 
            teachers.push_back(t);
        }
        saveTeachersToFile(); 
    }

    void saveTeachersToFile() {
        ofstream outFile(filename);
        if (outFile.is_open()) {
            for ( auto& teacher : teachers) {
                teacher.writeToFile(outFile);
                outFile << "--END_TEACHER--\n"; 
            }
            outFile.close();
            cout << "Teacher data saved to " << filename << endl;
        } else {
            cerr << "Error: Unable to open file for writing: " << filename << endl;
        }
    }

    void loadTeachersFromFile() {
        ifstream inFile(filename);
        if (inFile.is_open()) {
            teachers.clear(); 
            string line;
            while (true) {
                Teacher t;
              \
                if (inFile.peek() == EOF || inFile.fail()) {
                    break;
                }
                
                t.readFromFile(inFile); 
                if (inFile.fail()) {
                    
                    if (inFile.eof() && teachers.empty()) {
                         
                        cout << "File is empty or contains no complete records.\n";
                    } else if (!inFile.eof()) {
                        
                        cerr << "Error reading teacher data from file. Data might be corrupted or incomplete.\n";
                    }
                    break;
                }
                
              
                getline(inFile, line); 
                if (line.find("--END_TEACHER--") == string::npos) {
                    cerr << "Warning: Missing or corrupted teacher record separator after a read. Data might be incomplete.\n";
                   
                    break; 
                }

                teachers.push_back(t);
            }
            inFile.close();
            cout << "Teacher data loaded from " << filename << endl;
        } else {
            cerr << "Error: Unable to open file for reading: " << filename << endl;
        }
    }

    void generateDailyReport() {
        if (teachers.empty()) {
            cout << "No teacher data available. Please input teachers or load from file.\n";
            return;
        }
        cout << "\n--- Daily Report (" << reportDate << ") -----\n";
        for ( auto& teacher : teachers) {
            teacher.displayTeacherInfo();
            cout << "--------------------------------\n";
        }
    }

    void generateMonthlySummary() {
        cout << "Monthly summary feature under development...\n";
    }

    void generateUserSelectedDateSummary() {
        cout << "Selected date summary feature under development..\n";
    }

    ~ReportGenerator() {
        cout << "Cleaning up ReportGenerator resources...\n";
    }
};

int main() {
    ReportGenerator rg;
    int choice;

    do {
        cout << "\n--- Main Menu ---\n";
        cout << "1. Input Teacher Data\n";
        cout << "2. Load Teacher Data from File\n";
        cout << "3. Generate Daily Report\n";
        cout << "4. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                rg.inputTeachers();
                break;
            case 2:
                rg.loadTeachersFromFile();
                break;
            case 3:
                rg.generateDailyReport();
                break;
            case 4:
                cout << "Exiting program. Goodbye!\n";
                break;
            default:
                cout << "Invalid choice. Please try again.\n";
        }
    } while (choice != 4);

    return 0;
}
