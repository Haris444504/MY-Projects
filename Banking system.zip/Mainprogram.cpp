#include<iostream>
using namespace std ;

class Account{    // abstract class 
    protected:
    string  accountNumber;
    string  holderName;
    double balance;
    public:
    Account (){
        accountNumber="0000-0000000";
        holderName = "unknown";
        balance=  0;
    }  
    Account(string accountNumber,string holderName,double balance){
        this->accountNumber=accountNumber;
        this->holderName=holderName;
        this->balance=balance;
    }
    virtual void deposit() = 0; // pure virtual functions
    virtual void withdrawn() = 0;
    virtual void displaydetails()=0;
};

class Saving : public Account{ // inheritence 
string name;
string dateofbirth;
string phonenumber;
string CNIC;
bool iscreated ;
// double balance;
int pin ;
public : 
// default constructor
Saving(){
	name = "unknown";
	dateofbirth = "00-00-0000";
	phonenumber = "00-00-000000";
	CNIC = "00-00-0000000";
	iscreated = false ;
	// balance = 0.0;
	pin = 000;
	}
	// parametrized constructor
// 	Saving(string name, string dateofbirth,string phonenumber,string CNIC ,float balance ,int pin) 
// 	: Account(accountNumber , holderName, balance){
// 		this->name =name;
// 		this->dateofbirth =dateofbirth;
// 		this->phonenumber =phonenumber;
// 		this->CNIC =CNIC;
// 		this->balance =balance;
// 		this->pin = pin ;
// 	}
	void getInfo(){

		cout<<"-------------------Welcome to the Saving Account-------------------------\n"<<endl;
		cout<<"\n----Please enter your details to create a new account----\n"<<endl; 
        cin.ignore();
		cout<<" Enter your Name:";                   // getting all details
		getline(cin,name);
		cout<<"Enter your date of birth :";
		getline(cin,dateofbirth);
		cout<<"Enter your phone number (+92) :";
		getline(cin,phonenumber);
		cout<<"Enter your CNIC:";
		getline(cin,CNIC);
		cout<<"Enter pin :";
		cin>>pin;
		cout<<"Enter first deposit :";
		cin>>balance;
		string pinInput;
		cout<<"you want to save data or not ?(yes to save and no to Unsave) :  "; // saving confirmation
		cin>>pinInput;
		if(pinInput == "yes"){
			iscreated = true;              // this will create the acocunt 
			cout<<"Your account is created successfully."<<endl;
			cout<<"Your account details are as follows:"<<endl;
			displaydetails();
		}
		else if(pinInput == "no"){
			iscreated = false;
			}
		}
		void displaydetails() override {
			cout<<"-------------------Account Details-------------------------\n"<<endl;
			cout<<endl;
			cout<<"Account holder Name: "<< name<<endl;
			cout<<"Dateofbirth: "<<dateofbirth<<endl;
			cout<<"Phone number: "<< phonenumber<<endl;
			cout<<"CNIC: "<<CNIC<<endl;
			cout<<"balance: "<<balance<<endl;
		}
		
		void deposit() override {
			cout<<"Depsoit amount is : "<<balance<<endl;
		}
		void withdrawn() override{
			cout<<"Non------\n"<<endl;
		}
	// void Setvalue(string name, string dateofbirth,string phonenumber,string CNIC ,float balance){
	//     this->name =name;
	// 	this->dateofbirth =dateofbirth;
	// 	this->phonenumber =phonenumber;
	// 	this->CNIC =CNIC;
	// 	this->balance =balance;
	// 	this->pin = pin ;
	// }
	
	string getName(){              /// gatters 
		return name;
	}
	
	void setName(string name) {
		this->name = name;                                //  setters.
	}                              
	void setdateofbirth(string dateofbirth) {
		this->dateofbirth = dateofbirth;
	}
	void setphonenumber(string phonenumber) {
		this->phonenumber = phonenumber;
	}
	void setCNIC(string CNIC) {
		this->CNIC = CNIC;
	}
	void setPin(int pin) {
		this->pin = pin;
	}
	void setIscreated(bool iscreated) {
		this->iscreated = iscreated;
	}
	string getdateofbirth(){
		return dateofbirth;
	}
	string getphonenumber(){
		return phonenumber;
	}
	string getCNIC(){                            // all is encapsulation 
		return CNIC;
	}
	int getPin(){
		return pin ;
	}
	double getBalance(){
	    return balance ;
	}
	bool getIscreated(){
		return iscreated;}
		friend ostream& operator<<(ostream& os, const Saving& s);
	friend istream& operator>>(istream& is, Saving& s);
	};
class checkingAccount : public Account {
   string cnic;
   string number;
   int pinCode ;
   Saving S; ;
   double Withdraw;
   double Deposit;

	public:
	checkingAmount() {
	    // cnic = "0000-0000000-0";
	    // number = "0000-0000000";
	    // pinCode = 000;
	}
// 	checkingAccount(string c, string n,int p) : Saving() ,Account(accountNumber, holderName ,balance)
// 	{
// 		cnic=c;
// 		number=n;
// 		pinCode=p;
// 	}
	
	void deposit() override{
		cout<<"Enter the amount of deposit : ";
 		cin>>Deposit;                    // overriding to make the object of this class by avoiding it makig an abstract class
		
		balance += Deposit;
		cout<<"You have successfully deposit amount and your balance become : "<<balance<<endl; 
}
	
	void withdrawn() override{
	cout<<"Enter the amount of withdraw : ";
	cin>>  Withdraw;
	if(Withdraw > balance) {
	 cout<<"Insufficient balance. You cannot withdraw this amount."<<endl;
	 return;
 }
 if(Withdraw <= 0) {
  cout<<"Invalid amount. Please enter a positive amount to withdraw."<<endl;
  return;
 }
 else{
   balance -= Withdraw ;
   cout<<"you have sucessfully withdraw amount and your balance become:"<<balance<<endl;
 }
}
    void displaydetails() override {
        cout<<"non--\n"<<endl;
    }
   	void loginAccount(Saving S)
   	{
		this->S = S;
		if(S.getIscreated() == false){
			cout<<"You have not created an account yet. Please create an account first."<<endl;
			return;
		}
		else if(S.getIscreated() == true){
		cout<<"\n\n\n\n\n\n\n\n\n\n";
		cout<<"-------------------Welcome to the login system-------------------------\n"<<endl;
		cout<<"----Please enter your details to login----\n"<<endl;

   		cout<<"ENTER THE CNIC NUMBER:";
		cin.ignore();
   		getline(cin,cnic);
   		cout<<"ENTER THE NUMBER:";
   		getline(cin,number);
   		cout<<"ENTER THE PIN CODE TO LOGIN: ";
   		cin>>pinCode;
   		
   		if (cnic == S.getCNIC() && number == S.getphonenumber() && pinCode == S.getPin()){
   			cout<<"THE ACCOUNT IS LOGIN SUCCESSFULLY. NOW MOVE FORWARD"<<endl;
   			string option;
   			cout<<"Enter (check) to check your accounts detail or (move) to move towards app:";
   			cin>>option;
   		 	if (option == "check")
   		 {
   		 	cout<<"CNIC: "<<cnic<<endl;
   		 	cout<<"NUMBER:"<<number<<endl;
   		 	cout<<"PIN CODE:"<<pinCode<<endl;
			}
			else if (option == "move")
			{
				cout<<"------------You are now in the app.---------------"<<endl;
   			int choice ;
   			while(true){
			cout<<"-------------------Welcome to the Banking System-------------------------\n"<<endl;
   			cout<<"1-Use ATM machine."<<endl;
   			cout<<"2-Perfome transation."<<endl;
			cout<<"3-Exit."<<endl;
   			cout<<"ENTER THE CHOICE : ";
   			cin>>choice;
   			if (choice == 1)
   			{
                while(true){
   				cout<<"-------------------Welcome to the ATM machine-------------------------\n"<<endl;
   				int demand;
   				cout<<"1.DEPOSIT MONEY"<<endl;
			    cout<<"2.WITHDRAW MONEY"<<endl;
   				cout<<"3-CHECK THE BALANCE "<<endl;
   				cout<<"4-EXIT---"<<endl;
				cout<<"ENTER YOUR DEMAND : ";
   				cin>>demand;
   				if(demand == 1)
   				{
   					deposit();
				   }
				else if(demand == 2)
				{
					withdrawn();
				}
				else if(demand == 3)
				{
					cout<<"your current balance :  "<<balance<<endl;
				}
				else if(demand == 4)
				{
					cout<<"---------Exiting ATM machine.--------------"<<endl;
					break;
				}
				else
				{
					cout<<"Invalid input. Please try again."<<endl;
				}
			   }
			   
			}
			else if (choice ==2)
			{
				cout<<"Enter the amount you want to transfer : ";
				double transferAmount;
				cin>>transferAmount;

				// Perform the transfer operation
				cout<<"Enter the account number to transfer to: ";
				string transferAccountNumber;
				cin.ignore();
				getline(cin, transferAccountNumber);
				cout<<"Enter your pin : ";
				int transferPin;
				cin>>transferPin;
				if(transferPin == S.getPin()){
					if(transferAmount <= balance){
						balance -= transferAmount;
						cout<<"You have successfully transferred "<<transferAmount<<" to account number "<<transferAccountNumber<<". Your new balance is "<<balance<<endl;
					}
					else{
						cout<<"Insufficient balance. Transfer failed."<<endl;
					}
				}
				else{
					cout<<"Incorrect pin. Transfer failed."<<endl;
				}
			}
			else if (choice == 3)
			{
				cout<<"Exiting the banking system."<<endl;
				cout<<"\n--------------------Returning to the main menu.-----------------------"<<endl;
				return ;

			}
			else
			{
				cout<<"Invalid input. Please try again."<<endl;
		   }
			   }
			}
   		else {
   			cout<<"The details you entered are incorrect. Please try again."<<endl;
   		}	
	} 
}
	}
};
ostream& operator<<(ostream& os, const Saving& s) {         // operatoroverloading 
	os << s.name << endl;
	os << s.dateofbirth << endl;
	os << s.phonenumber << endl;
	os << s.CNIC << endl;
	os << s.balance << endl;
	os << s.pin << endl;
	return os;
}

istream& operator>>(istream& is, Saving& s) {
	cout<< "Enter account name :" << endl;
	getline(is, s.name);
	cout<< "Enter date of birth :" << endl;
	getline(is, s.dateofbirth);
	cout<< "Enter phone number :" << endl;
	getline(is, s.phonenumber);
	cout<< "Enter CNIC :" << endl;
	s.iscreated = true; 
	getline(is, s.CNIC);
	is >> s.balance;
	is >> s.pin;
	is.ignore(); 
	return is;
}
class ClosedAccount{
	string cN;
	string pNo ;
	Saving* S ; // aggergation
	public :
		void Closed(Saving* S) {
 this->S = S;
 	{
 		cout << "CNIC: ";
 		cin >> cN;
 		cout << "Phonenumber: ";
 		cin >> pNo;

 		if(S->getIscreated() == false){
 			cout<<"You have not created an account yet. Please create an account first."<<endl;
 			return;
 		}
 		if(S->getIscreated() == true && cN == S->getCNIC()  && pNo == S->getphonenumber()){

 			cout<<"Are you sure you want to delete your account? (yes/no): ";
 			string opinion;
 			cin>>opinion;
 			if(opinion == "yes"){
			S->setIscreated(false);
 				cout<< "Account is closed:" <<endl;
 			}
 			else if (opinion == "no")
 			{
 				cout<<"Account closure canceled."<<endl;
 			}
 		}
 		else {
 			cout << "CNIC or Phone number is incorrect. Account deletion failed." << endl;
 		}
 	}
}
	void calculateBalance(){          // function overloading 
		cout<<"Your current balance is: "<<S->getBalance()<<endl;
	}
	void calculateBalance(int deposit){
		cout<<"Your current balance is: "<<S->getBalance()+deposit<<endl;
	}
	friend void checkAccountBalance();
};

void checkAccountBalance(Saving * S) {         // freind function
	cout<<"Want to check the balance before deleting the account? (yes/no): ";
	string checkBalance;
	cin>>checkBalance;
	if(checkBalance == "yes"){
		cout<<"Your current balance is: "<<S->getBalance()<<endl;
	}
	else if(checkBalance == "no"){
		cout<<"You have chosen not to check the balance."<<endl;
	}
	else {
		cout<<"Invalid input. Please try again."<<endl;
	}
}
class Update{
    string Cnic ;
    string Name ;
    string phoneNumber ;
    int PIN ;
    int CPin;
	Saving S;            // composition 
    public :
    Update(){
        
    }
    
    void updatedetails(Saving S){        // association
		this->S = S;
		cout<<"\n\n\n\n\n\n\n\n\n\n";
		if(S.getIscreated() == false){
				cout<<"You have not created an account yet. Please create an account first."<<endl;
			}
			else if(S.getIscreated() == true){
				while (true)
				{
					cout<<"You can update your account details now."<<endl;
        cout<<"1-Update specific deatil."<<endl;
        cout<<"2-Update all details."<<endl;
        cout<<"3-Exit."<<endl;
        int Type ;
        cout<<"Enter choice : ";
        cin>>Type ;

        if(Type == 1){
            cout<<"what you want to change ( cnic \n , phone number , pin ): ";
            string tell;
			cin>>tell;
            if(tell == "pin"){
                cout<<"Enter new one : ";
                cin>>PIN;
                cout<<"Enter one time more for comfirm it :  ";
                cin>>CPin;
                if(CPin == PIN){
                    cout<<"Pin is  changed successfully. "<<endl;
					S.setPin(PIN);
				}
				else {
					cout<<"Pin does not match. Please try again."<<endl;
					continue;
                }
            }
            if(tell == "cnic"){
                cout<<"Enter new cnic : ";
                getline(cin,Cnic);
                S.setCNIC(Cnic);
                cout<<"CNIC changed successfully."<<endl;
            }
            if(tell == "phonenumber"){
                cout<<"Enter new phone number : ";
                getline(cin,phoneNumber);
                cout<<"Phone Number changed."<<endl;
				S.setphonenumber(phoneNumber);
            }
            if(tell == "name"){
                cout<<"Enter new Name : ";
                getline(cin,Name);
                S.setName(Name);
                cout<<" Name is changed."<<endl;
            }
        }
        if(Type == 2){
            cout<<"Enter new Name : ";
            getline(cin,Name);
			S.setName(Name);
            cout<<"Enter new phone number : ";
            getline(cin,phoneNumber);
			S.setphonenumber(phoneNumber);
            cout<<"Enter new one : ";
            cin>>PIN;
            cout<<"Enter one time more for comfirm it :  ";
            cin>>CPin;
            if(CPin == PIN){
                    cout<<"Pin is  changed successfully. "<<endl;
					S.setPin(PIN);
            }
            cout<<"Enter new cnic : ";
            getline(cin,Cnic);
            S.setCNIC(Cnic);
            cout<<"All information upadte succesfully!"<<endl;
        }
         if(Type == 3){
			cout<<"Exiting for update."<<endl;
			break;
		}
		else {
			cout<<"Invalid input. Please try again."<<endl;
		}	}
}
	}
};
int main(){
    int choice ;
    Account* A;       // pointers for runtime or late binding
    Saving S ;
    A = &S;
    checkingAccount C ;
	ClosedAccount C1 ;
	Update U;
    while(true){
		cout<<"\n\n\n\n\n\n\n\n\n\n";
		cout<<"--------------------------------WELCOME TO BANKING SYSTEM-------------------------------\n"<<endl;
		cout<<"Please select an option from the menu below:"<<endl;
        cout<<"\n1-Create and save new account."<<endl;
        cout<<"2-Login and use Existing Account."<<endl;
        cout<<"3-Update Account information."<<endl;
        cout<<"4-Close Account."<<endl;
        cout<<"5-Exit for system."<<endl;
        cout<<"Enter Choice : ";
        cin>>choice;
        
        switch(choice){
            case 1 :
			cout<<"Enter your details.....\n"<<endl; 
			S.getInfo();
//			A->deposit();
			break;
            case 2 : C.loginAccount(S);
            break ;
            case 3 : U.updatedetails(S);
			break;
            case 4 : C1.Closed(&S);
			break;
            case 5 :{
                cout<<"Exiting----"<<endl;
                exit(0);
            } 
            default : cout<<"Invalide input."<<endl;
            return 0;
        }
}
	return 0;
}
   
